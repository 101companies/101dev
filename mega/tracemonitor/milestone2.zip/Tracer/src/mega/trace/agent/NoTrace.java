package mega.trace.agent;

/*
 * When using Java Agent, annotated @NoTrace classes wont get traced.
 */

public @interface NoTrace {}
