package mega.trace.event;

public class LocalVariableAssignmentEvent extends VariableAssignmentEvent {
	

	public LocalVariableAssignmentEvent(String index,String signature) {
		super(index,signature);
	
	}
	
	
}
