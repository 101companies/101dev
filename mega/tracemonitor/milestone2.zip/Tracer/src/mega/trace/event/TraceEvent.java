package mega.trace.event;

public abstract class TraceEvent {

	public TraceEvent(){

	}
	
	
}
