package mega.trace.event;

public class ObjectCreationEvent extends TraceEvent {
	
	
	public ObjectCreationEvent(Object x,String u) {
		super();
	
	}

	

}
